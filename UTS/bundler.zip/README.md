## Portfolio Website
### mengintegrasikan three js sebagai framework 3d, objek 3d yang kami gunakan adalah photogrammetry menggunakan handphone, pada tampilan paling atas memuncullkan parallax ketika mouse bergerak dan yang dibawahnya menggerakkan kamera berdasarkan opsi yang kita tekan.

## Run Local
Download dan instal Node.js (https://nodejs.org/en/download/)

Lalu jalankan kedua perintah command berikut dalam folder project
```
  npm install
```
```
  npm run dev
```
